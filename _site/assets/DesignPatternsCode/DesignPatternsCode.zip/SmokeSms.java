public class SmokeSms {
    public void sendMessage(String s){
        System.out.println("SMS from SMOKE detector. Message is: "+s);
        //real SMS code goes here
    }
}
