public class AlarmForMotion {
    void start() {
        System.out.println("Alarm Started..");
    }

    void stop() {
        System.out.println("Alarm stopped..");
    }
}