interface SensorListener {
    void detected();
}
