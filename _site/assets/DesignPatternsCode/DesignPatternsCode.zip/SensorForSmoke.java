public interface SensorForSmoke {
    String getDescription();
}