public interface SensorForMotion {
    String getDescription();
}