public interface Sms {
    void sendMessage(String s);
}
