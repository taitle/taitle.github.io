public class MotionSms {
    public void sendMessage(String s){
        System.out.println("SMS from MOTION detector. Message is: "+s);
        //real SMS code goes here
    }
}
