public class SprinklerForSmoke {
    public  void turnOn() {
        System.out.println("Sprinkler is on");
    }

    public void turnOff() {
        System.out.println("Sprinkler is off");
    }
}